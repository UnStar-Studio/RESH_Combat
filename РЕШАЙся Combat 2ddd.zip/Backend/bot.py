import telebot
from bs4 import BeautifulSoup

TOKEN = '7682522959:AAF8h814gzwykGsQwkdxEEMKxymDmCDDr7M'
bot = telebot.TeleBot(TOKEN)

def get_data_from_website():
    """Парсит HTML файл и извлекает данные из элемента с id="my_data"."""
    try:
        with open("C:/Users/Lenya/Desktop/РЕШАЙся Combat 2/Fronted/index.html", "r", encoding="utf-8") as f:
            hhtml_content = f.read()

        soup = BeautifulSoup(html_content, "html.parser")

        # Находим div с классом "content"
        content_div = soup.find("div", class_="content")

        if content_div:
            # Находим div с классом "tab active-tab"
            game_tab_div = content_div.find("div", class_="tab active-tab")

            if game_tab_div:
                # Теперь ищем элемент с id="coinCounter" внутри game_tab_div
                coin_counter_element = game_tab_div.find(id="coinCounter")

                if coin_counter_element:
                    data = coin_counter_element.text
                else:
                    data = "Элемент с id='coinCounter' не найден внутри gameTab!"
            else:
                data = "Div с классом 'tab active-tab' не найден!"
        else:
            data = "Div с классом 'content' не найден!"

        return data
    except FileNotFoundError:
        return "Файл index.html не найден!"
    except Exception as e:
        return f"Ошибка при чтении файла: {e}"

@bot.message_handler(commands=['data'])
def send_data(message):
    data = get_data_from_website()
    bot.reply_to(message, data)

bot.infinity_polling()
