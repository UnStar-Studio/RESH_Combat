var MainBtn = document.getElementById('mainBtn');
var MainTxt = document.getElementById('mainTxt');
var ClicksTxt = document.getElementById('CoinsTxt');

var ClickCount = localStorage.getItem("ClickCount");

MainTxt.innerText = ClickCount;
ClicksTxt.innerText = ClickCount;

MainBtn.addEventListener('click', function() {
    ClickCount ++;
    MainTxt.innerText = ClickCount;
    ClicksTxt.innerText = "Коинов: " + ClickCount;

    //Сохранения, НЕ МЕНЯТЬ КЛЮЧ А ТО У ВСЕХ СОХРАНЕНИЯ ПРОПАДУТ!!!!
    localStorage.setItem("ClickCount", ClickCount);
  });